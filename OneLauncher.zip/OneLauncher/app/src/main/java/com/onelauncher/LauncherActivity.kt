package com.onelauncher

import android.app.Activity
import android.app.ActivityOptions
import android.app.AlertDialog
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.GestureDetector
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import java.util.Collections
import kotlin.math.abs

class LauncherActivity : Activity() {
    companion object { const val REQ_BIND = 11; const val REQ_CFG = 12; const val MATCH = -1; const val WRAP = -2 }
    private enum class Where { HOME, DOCK, DRAWER }

    private lateinit var prefs: SharedPreferences
    private lateinit var awm: AppWidgetManager
    private lateinit var host: AppWidgetHost
    private lateinit var root: FrameLayout
    private lateinit var homeCol: LinearLayout
    private lateinit var widgetBox: LinearLayout
    private lateinit var homeRv: RecyclerView
    private lateinit var dock: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var drawerRv: RecyclerView
    private lateinit var searchEt: EditText
    private lateinit var editBar: LinearLayout
    private lateinit var homeAdapter: AppAdapter
    private lateinit var drawerAdapter: AppAdapter
    private lateinit var touchHelper: ItemTouchHelper

    private var allApps = listOf<AppInfo>()
    private val homeApps = mutableListOf<AppInfo>()
    private val dockApps = mutableListOf<AppInfo>()
    private var drawerOpen = false
    private var editShown = false
    private var popup: PopupWindow? = null
    private var pendingWidgetId = -1

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { reload() }
    }

    private val gd by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                val dy = e2.rawY - (e1?.rawY ?: return false)
                if (!drawerOpen && dy < -dp(80) && vy < -800 && abs(vy) > abs(vx)) { openDrawer(); return true }
                if (drawerOpen && dy > dp(80) && vy > 800 && !drawerRv.canScrollVertically(-1)) { closeDrawer(); return true }
                return false
            }
            override fun onLongPress(e: MotionEvent) { if (!drawerOpen) onHomeLongPress(e) }
        })
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)
    private fun cols() = prefs.getInt("cols", 4)
    private fun labels() = prefs.getBoolean("labels", true)
    private fun rounded(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = r.toFloat() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("launcher", MODE_PRIVATE)
        awm = AppWidgetManager.getInstance(this)
        host = AppWidgetHost(this, 1024)
        window.setDecorFitsSystemWindows(false)
        buildUi()
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED); addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(pkgReceiver, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(pkgReceiver, f)
        reload()
    }

    private fun buildUi() {
        root = FrameLayout(this)
        setContentView(root)
        root.setOnApplyWindowInsetsListener { v, ins ->
            val sb = ins.getInsets(WindowInsets.Type.systemBars())
            val ime = ins.getInsets(WindowInsets.Type.ime())
            v.setPadding(0, sb.top, 0, maxOf(sb.bottom, ime.bottom)); ins
        }

        homeAdapter = AppAdapter({ labels() }, { v, a -> launch(v, a) }, { vh, a ->
            showMenu(vh.itemView, a, Where.HOME); touchHelper.startDrag(vh)
        })
        drawerAdapter = AppAdapter({ labels() }, { v, a -> launch(v, a) }, { vh, a -> showMenu(vh.itemView, a, Where.DRAWER) })
        homeAdapter.items = homeApps

        homeCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        widgetBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), 0) }
        homeRv = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@LauncherActivity, cols())
            adapter = homeAdapter; overScrollMode = View.OVER_SCROLL_NEVER
            clipToPadding = false; setPadding(dp(8), dp(8), dp(8), 0)
        }
        touchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT, 0) {
            override fun isLongPressDragEnabled() = false
            override fun onMove(rv: RecyclerView, a: RecyclerView.ViewHolder, t: RecyclerView.ViewHolder): Boolean {
                dismissPopup()
                Collections.swap(homeApps, a.bindingAdapterPosition, t.bindingAdapterPosition)
                homeAdapter.notifyItemMoved(a.bindingAdapterPosition, t.bindingAdapterPosition); return true
            }
            override fun onSwiped(vh: RecyclerView.ViewHolder, d: Int) {}
            override fun clearView(rv: RecyclerView, vh: RecyclerView.ViewHolder) { super.clearView(rv, vh); saveHome() }
        })
        touchHelper.attachToRecyclerView(homeRv)

        val pill = TextView(this).apply {
            text = "Rechercher"; textSize = 15f; setTextColor(Color.parseColor("#CCFFFFFF"))
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(22), 0, dp(22), 0)
            background = rounded(Color.parseColor("#66202428"), dp(26))
            setOnClickListener { openDrawer(true) }
        }
        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            background = rounded(Color.parseColor("#40FFFFFF"), dp(32)); setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        homeCol.addView(widgetBox, lp(MATCH, WRAP))
        homeCol.addView(homeRv, lp(MATCH, 0, 1f))
        homeCol.addView(pill, lp(MATCH, dp(50)).apply { setMargins(dp(20), dp(4), dp(20), dp(8)) })
        homeCol.addView(dock, lp(MATCH, WRAP).apply { setMargins(dp(14), 0, dp(14), dp(10)) })
        root.addView(homeCol, FrameLayout.LayoutParams(MATCH, MATCH))

        // Tiroir d'applications
        val r = dp(32).toFloat()
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            background = GradientDrawable().apply { setColor(Color.parseColor("#F0101418")); cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f) }
            setPadding(dp(8), dp(16), dp(8), 0)
        }
        searchEt = EditText(this).apply {
            hint = "Rechercher"; setHintTextColor(Color.parseColor("#99FFFFFF")); setTextColor(Color.WHITE)
            background = rounded(Color.parseColor("#33FFFFFF"), dp(26)); setPadding(dp(22), 0, dp(22), 0)
            isSingleLine = true; textSize = 16f
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    val q = s?.toString()?.trim().orEmpty()
                    drawerAdapter.items = allApps.filter { it.label.contains(q, true) }.toMutableList()
                    drawerAdapter.notifyDataSetChanged()
                }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        drawerRv = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@LauncherActivity, cols()); adapter = drawerAdapter
            clipToPadding = false; setPadding(0, dp(8), 0, dp(24))
        }
        drawer.addView(searchEt, lp(MATCH, dp(50)).apply { setMargins(dp(12), 0, dp(12), dp(8)) })
        drawer.addView(drawerRv, lp(MATCH, 0, 1f))
        root.addView(drawer, FrameLayout.LayoutParams(MATCH, MATCH))

        // Barre d'édition (appui long sur l'accueil)
        editBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; visibility = View.GONE
            background = rounded(Color.parseColor("#F2262B33"), dp(28)); setPadding(dp(8), dp(14), dp(8), dp(14))
        }
        fun editBtn(t: String, ic: Int, act: () -> Unit) = TextView(this).apply {
            text = t; textSize = 12f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setCompoundDrawablesWithIntrinsicBounds(0, ic, 0, 0); compoundDrawablePadding = dp(6)
            compoundDrawableTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            setOnClickListener { hideEditBar(); act() }
        }
        editBar.addView(editBtn("Fond d'écran et style", android.R.drawable.ic_menu_gallery) {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Fond d'écran"))
        }, lp(0, WRAP, 1f))
        editBar.addView(editBtn("Widgets", android.R.drawable.ic_menu_add) { pickWidget() }, lp(0, WRAP, 1f))
        editBar.addView(editBtn("Paramètres", android.R.drawable.ic_menu_preferences) { showSettings() }, lp(0, WRAP, 1f))
        root.addView(editBar, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM).apply { setMargins(dp(12), 0, dp(12), dp(12)) })
    }

    // ---------- Données ----------
    private fun reload() {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        allApps = pm.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { AppInfo(it.loadLabel(pm).toString(), ComponentName(it.activityInfo.packageName, it.activityInfo.name), it.loadIcon(pm)) }
            .sortedBy { it.label.lowercase() }
        fun resolve(k: String) = ComponentName.unflattenFromString(k)?.let { c -> allApps.firstOrNull { it.component == c } }
        if (!prefs.contains("home"))
            prefs.edit().putString("home", allApps.take(16).joinToString("\n") { it.component.flattenToString() }).apply()
        homeApps.clear()
        homeApps.addAll(prefs.getString("home", "")!!.split("\n").mapNotNull { resolve(it) })
        dockApps.clear()
        dockApps.addAll(prefs.getString("dock", null)?.split("\n")?.mapNotNull { resolve(it) } ?: defaultDock())
        drawerAdapter.items = allApps.toMutableList()
        homeAdapter.notifyDataSetChanged(); drawerAdapter.notifyDataSetChanged(); refreshDock()
    }

    private fun defaultDock(): List<AppInfo> {
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE))
        return intents.mapNotNull { i ->
            val p = packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
            allApps.firstOrNull { it.component.packageName == p }
        }.distinctBy { it.component }
    }

    private fun saveHome() = prefs.edit().putString("home", homeApps.joinToString("\n") { it.component.flattenToString() }).apply()
    private fun saveDock() = prefs.edit().putString("dock", dockApps.joinToString("\n") { it.component.flattenToString() }).apply()

    private fun refreshDock() {
        dock.removeAllViews()
        dockApps.forEach { app ->
            val c = Cell(this).apply { bind(app, false) }
            c.setOnClickListener { launch(it, app) }
            c.setOnLongClickListener { showMenu(it, app, Where.DOCK); true }
            dock.addView(c, lp(0, WRAP, 1f))
        }
    }

    private fun launch(v: View, app: AppInfo) {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(app.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try { startActivity(i, ActivityOptions.makeScaleUpAnimation(v, 0, 0, v.width, v.height).toBundle()) }
        catch (e: Exception) { Toast.makeText(this, "Impossible d'ouvrir l'application", Toast.LENGTH_SHORT).show() }
    }

    // ---------- Menu d'appui long sur une icône ----------
    private fun shortcutsFor(pkg: String): List<ShortcutInfo> = try {
        val q = LauncherApps.ShortcutQuery().setPackage(pkg).setQueryFlags(
            LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED)
        getSystemService(LauncherApps::class.java).getShortcuts(q, android.os.Process.myUserHandle())?.take(4) ?: emptyList()
    } catch (e: Exception) { emptyList() }

    private fun showMenu(anchor: View, app: AppInfo, where: Where) {
        dismissPopup()
        anchor.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        anchor.animate().scaleX(1.12f).scaleY(1.12f).setDuration(200).setInterpolator(OvershootInterpolator(2f)).start()
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.parseColor("#F2262B33"), dp(26)); setPadding(dp(6), dp(8), dp(6), dp(8))
        }
        fun row(text: String, danger: Boolean = false, act: () -> Unit) {
            card.addView(TextView(this).apply {
                this.text = text; textSize = 15f
                setTextColor(if (danger) Color.parseColor("#FF6B6B") else Color.WHITE)
                setPadding(dp(16), dp(12), dp(16), dp(12))
                setOnClickListener { dismissPopup(); act() }
            }, lp(MATCH, WRAP))
        }
        val pkg = app.component.packageName
        val shortcuts = shortcutsFor(pkg)
        val la = getSystemService(LauncherApps::class.java)
        shortcuts.forEach { s ->
            row(s.shortLabel?.toString() ?: s.id) {
                try { la.startShortcut(s.`package`, s.id, null, null, android.os.Process.myUserHandle()) } catch (_: Exception) {}
            }
        }
        if (shortcuts.isNotEmpty()) card.addView(View(this).apply { setBackgroundColor(Color.parseColor("#22FFFFFF")) }, lp(MATCH, 2))
        when (where) {
            Where.HOME -> row("Retirer de l'accueil") { homeApps.removeAll { it.component == app.component }; saveHome(); homeAdapter.notifyDataSetChanged() }
            Where.DOCK -> row("Retirer du dock") { dockApps.removeAll { it.component == app.component }; saveDock(); refreshDock() }
            Where.DRAWER -> {
                row("Ajouter à l'accueil") {
                    if (homeApps.none { it.component == app.component }) { homeApps.add(app); saveHome(); homeAdapter.notifyDataSetChanged() }
                    closeDrawer()
                }
                if (dockApps.size < 5) row("Ajouter au dock") { dockApps.add(app); saveDock(); refreshDock() }
            }
        }
        row("Infos sur l'appli") { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))) }
        row("Désinstaller", true) { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))) }

        val w = dp(230); val dm = resources.displayMetrics
        card.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val h = card.measuredHeight
        val loc = IntArray(2); anchor.getLocationOnScreen(loc)
        val x = (loc[0] + anchor.width / 2 - w / 2).coerceIn(dp(12), dm.widthPixels - w - dp(12))
        var y = loc[1] + anchor.height + dp(8); var above = false
        if (y + h > dm.heightPixels - dp(40)) { y = loc[1] - h - dp(8); above = true }
        card.pivotX = (loc[0] + anchor.width / 2 - x).toFloat(); card.pivotY = if (above) h.toFloat() else 0f
        card.alpha = 0f; card.scaleX = 0.7f; card.scaleY = 0.7f
        popup = PopupWindow(card, w, WRAP, true).apply {
            setBackgroundDrawable(ColorDrawable(0)); isOutsideTouchable = true; elevation = dp(16).toFloat()
            setOnDismissListener { anchor.animate().scaleX(1f).scaleY(1f).setDuration(150).start() }
            showAtLocation(root, Gravity.NO_GRAVITY, x, y)
        }
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun dismissPopup() { popup?.dismiss(); popup = null }

    // ---------- Tiroir ----------
    private fun openDrawer(focus: Boolean = false) {
        if (drawerOpen) return
        drawerOpen = true
        drawer.visibility = View.VISIBLE
        drawer.translationY = resources.displayMetrics.heightPixels.toFloat()
        drawer.animate().translationY(0f).setDuration(320).setInterpolator(DecelerateInterpolator(1.5f)).start()
        homeCol.animate().alpha(0f).setDuration(250).start()
        if (focus) {
            searchEt.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(searchEt, 0)
        }
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(searchEt.windowToken, 0)
        searchEt.setText(""); searchEt.clearFocus()
        homeCol.animate().alpha(1f).setDuration(250).start()
        drawer.animate().translationY(resources.displayMetrics.heightPixels.toFloat()).setDuration(260)
            .setInterpolator(DecelerateInterpolator()).withEndAction { drawer.visibility = View.GONE; drawerRv.scrollToPosition(0) }.start()
    }

    // ---------- Appui long sur l'accueil, widgets, réglages ----------
    private fun inside(v: View, e: MotionEvent): Boolean {
        val l = IntArray(2); v.getLocationOnScreen(l)
        return e.rawX >= l[0] && e.rawX <= l[0] + v.width && e.rawY >= l[1] && e.rawY <= l[1] + v.height
    }

    private fun onHomeLongPress(e: MotionEvent) {
        for (i in 0 until widgetBox.childCount) {
            val c = widgetBox.getChildAt(i)
            if (inside(c, e)) { confirmRemoveWidget(c.tag as Int); return }
        }
        if (inside(dock, e)) return
        val l = IntArray(2); homeRv.getLocationOnScreen(l)
        if (homeRv.findChildViewUnder(e.rawX - l[0], e.rawY - l[1]) != null) return
        showEditBar()
    }

    private fun showEditBar() {
        if (editShown) return
        editShown = true; editBar.visibility = View.VISIBLE; editBar.translationY = dp(160).toFloat()
        editBar.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        editBar.animate().translationY(0f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun hideEditBar() {
        if (!editShown) return
        editShown = false
        editBar.animate().translationY(dp(160).toFloat()).setDuration(200).withEndAction { editBar.visibility = View.GONE }.start()
    }

    private fun widgetIds() = prefs.getString("widgets", "")!!.split(",").mapNotNull { it.toIntOrNull() }
    private fun saveWidgets(ids: List<Int>) = prefs.edit().putString("widgets", ids.joinToString(",")).apply()

    private fun refreshWidgets() {
        widgetBox.removeAllViews()
        for (id in widgetIds()) {
            val info = awm.getAppWidgetInfo(id) ?: continue
            val hv = host.createView(applicationContext, id, info)
            val wrap = FrameLayout(this).apply { background = rounded(0, dp(24)); clipToOutline = true; tag = id; addView(hv) }
            widgetBox.addView(wrap, lp(MATCH, info.minHeight.coerceIn(dp(80), dp(260))).apply { bottomMargin = dp(8) })
        }
    }

    private fun pickWidget() {
        val pm = packageManager
        val list = awm.installedProviders.sortedBy { it.loadLabel(pm).lowercase() }
        val names = list.map { it.loadLabel(pm) + "  (" + runCatching { pm.getApplicationLabel(pm.getApplicationInfo(it.provider.packageName, 0)) }.getOrDefault(it.provider.packageName) + ")" }
        AlertDialog.Builder(this).setTitle("Widgets").setItems(names.toTypedArray()) { _, i -> addWidget(list[i]) }.show()
    }

    private fun addWidget(p: AppWidgetProviderInfo) {
        val id = host.allocateAppWidgetId(); pendingWidgetId = id
        if (awm.bindAppWidgetIdIfAllowed(id, p.provider)) configureOrAdd(id)
        else startActivityForResult(Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, p.provider), REQ_BIND)
    }

    private fun configureOrAdd(id: Int) {
        pendingWidgetId = id
        if (awm.getAppWidgetInfo(id)?.configure != null) host.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CFG, null)
        else commitWidget(id)
    }

    private fun commitWidget(id: Int) { saveWidgets(widgetIds() + id); refreshWidgets() }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == REQ_BIND) { if (res == RESULT_OK) configureOrAdd(pendingWidgetId) else host.deleteAppWidgetId(pendingWidgetId) }
        if (req == REQ_CFG) { if (res == RESULT_OK) commitWidget(pendingWidgetId) else host.deleteAppWidgetId(pendingWidgetId) }
    }

    private fun confirmRemoveWidget(id: Int) {
        AlertDialog.Builder(this).setMessage("Supprimer ce widget ?").setNegativeButton("Annuler", null)
            .setPositiveButton("Supprimer") { _, _ -> host.deleteAppWidgetId(id); saveWidgets(widgetIds() - id); refreshWidgets() }.show()
    }

    private fun showSettings() {
        val items = arrayOf("Accueil : 4 colonnes", "Accueil : 5 colonnes", "Accueil : 6 colonnes", "Afficher / masquer les noms")
        AlertDialog.Builder(this).setTitle("Paramètres").setItems(items) { _, i ->
            if (i < 3) prefs.edit().putInt("cols", 4 + i).apply() else prefs.edit().putBoolean("labels", !labels()).apply()
            (homeRv.layoutManager as GridLayoutManager).spanCount = cols()
            (drawerRv.layoutManager as GridLayoutManager).spanCount = cols()
            homeAdapter.notifyDataSetChanged(); drawerAdapter.notifyDataSetChanged()
        }.show()
    }

    // ---------- Cycle de vie ----------
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (editShown && ev.action == MotionEvent.ACTION_DOWN) {
            val l = IntArray(2); editBar.getLocationOnScreen(l)
            if (ev.rawY < l[1]) hideEditBar()
        }
        gd.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onStart() { super.onStart(); host.startListening(); refreshWidgets() }
    override fun onStop() { super.onStop(); host.stopListening() }
    override fun onDestroy() { super.onDestroy(); unregisterReceiver(pkgReceiver) }

    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        dismissPopup(); hideEditBar(); closeDrawer(); homeRv.scrollToPosition(0)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (editShown) hideEditBar() else if (drawerOpen) closeDrawer()
    }
}
