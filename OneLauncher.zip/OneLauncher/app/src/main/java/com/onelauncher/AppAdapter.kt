package com.onelauncher

import android.content.ComponentName
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class AppInfo(val label: String, val component: ComponentName, val icon: Drawable)

class Cell(c: Context) : LinearLayout(c) {
    val icon = ImageView(c)
    val label = TextView(c)

    init {
        val d = c.resources.displayMetrics.density
        orientation = VERTICAL
        gravity = Gravity.CENTER
        setPadding(0, (8 * d).toInt(), 0, (8 * d).toInt())
        addView(icon, LayoutParams((58 * d).toInt(), (58 * d).toInt()))
        label.apply {
            setTextColor(Color.WHITE); textSize = 11f; maxLines = 1
            ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
            setShadowLayer(4f, 0f, 1f, Color.BLACK)
            setPadding(4, 4, 4, 0)
        }
        addView(label, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    fun bind(app: AppInfo, showLabel: Boolean) {
        icon.setImageDrawable(app.icon)
        label.text = app.label
        label.visibility = if (showLabel) View.VISIBLE else View.GONE
    }
}

class AppAdapter(
    private val showLabels: () -> Boolean,
    private val onClick: (View, AppInfo) -> Unit,
    private val onLong: (RecyclerView.ViewHolder, AppInfo) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {
    var items: MutableList<AppInfo> = mutableListOf()

    class VH(val cell: Cell) : RecyclerView.ViewHolder(cell)

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(Cell(p.context).apply { layoutParams = RecyclerView.LayoutParams(-1, -2) })

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val a = items[i]
        h.cell.bind(a, showLabels())
        h.cell.setOnClickListener { onClick(it, a) }
        h.cell.setOnLongClickListener { onLong(h, a); true }
    }
}
