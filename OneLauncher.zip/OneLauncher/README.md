# One UI Launcher
Launcher Android natif (Kotlin) inspiré de One UI : accueil en grille réorganisable, dock, tiroir d'applications avec recherche,
menu d'appui long animé (raccourcis d'app, infos, désinstaller), widgets Android, barre d'édition (appui long sur le fond).
Build : ouvrir dans Android Studio, ou push sur GitHub (workflow inclus, APK en artefact). Puis Paramètres > Applis par défaut > Appli d'accueil.
